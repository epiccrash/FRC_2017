package org.usfirst.frc.team3062.robot.subsystems;

import edu.wpi.first.wpilibj.Relay;

public class Pickup {

	
	private Relay pickupRelay;
	
	
	
}
