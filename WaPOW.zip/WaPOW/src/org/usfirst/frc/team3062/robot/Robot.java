
package org.usfirst.frc.team3062.robot;

import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;

import org.usfirst.frc.team3062.robot.commands.AutonomousCommand;
import org.usfirst.frc.team3062.robot.commands.CompressorCheck;
import org.usfirst.frc.team3062.robot.commands.DriveWithJoystick;
import org.usfirst.frc.team3062.robot.subsystems.Catapult;
//import org.usfirst.frc.team3062.robot.commands.ExampleCommand;
//import org.usfirst.frc.team3062.robot.subsystems.Catapult;
import org.usfirst.frc.team3062.robot.subsystems.Chassis;
//import org.usfirst.frc.team3062.robot.subsystems.ExampleSubsystem;
import org.usfirst.frc.team3062.robot.subsystems.Shooter;

import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {

	//public static final ExampleSubsystem exampleSubsystem = new ExampleSubsystem();
	public static OI oi;
	public static final Catapult ramp = new Catapult();
	public static final Chassis chassis = new Chassis();
	public static final Shooter shooter = new Shooter();
	//public static final Catapult catapult = new Catapult();

	//added this
	Command teleopCommand;
    Command autonCommand;
    SendableChooser<Object> chooser;
    // Compressor compy = new Compressor();
    // Relay spike = new Relay( 0 );
    //CompressorCheck check;
    
    double dis;
    double turnDis;

    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    public void robotInit() {
		oi = new OI();
		
		//System.out.println("The OI was instantiated");
		
        chooser = new SendableChooser<>();
        // chooser.addDefault( "Center", new AutonomousCommand() );
        // chooser.addObject( "Left", new LeftCommand() );
        // chooser.addObject( "Right", new RightCommand() );
        // SmartDashboard.putData( "Autonomous chooser", chooser );
        
        chassis.resetAllDis(0);
        dis = chassis.getDis();
        turnDis = chassis.getTurnDis();
        SmartDashboard.putNumber("Distance", dis);
        SmartDashboard.putNumber("Turning Distance", turnDis);
        
        
        /*
         * SUGGESTED, going off of guide on WPILIB:
         * 
         * chooser = new SendableChooser();
         * chooser.addDefault( "Name of default autonomous program", new CommandEncapsulatingMainAutonomous() );
         * chooser.addObject( "Name of second autonomous program", new CommandEncapsulatingSecondAutonomous() );
         * chooser.addObject( "Name of third autonomous program", new CommandEncapsulatingThirdAutonomous() );
         * 
         */
        
        
        
        //autonCommand = new AutonomousCommand();
        
       
       // chooser.addDefault("Default Auto", new ExampleCommand());
        //chooser.addObject("My Auto", new MyAutoCommand());
        CameraServer.getInstance().startAutomaticCapture();
        
        //SmartDashboard.putData("Auto mode", chooser);
        
        //DriveWithJoystick drive = new DriveWithJoystick();
        //drive.start();
    }
	
	/**
     * This function is called once each time the robot enters Disabled mode.
     * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
     */
    public void disabledInit(){

    }
	
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select between different autonomous modes
	 * using the dashboard. The sendable chooser code works with the Java SmartDashboard. If you prefer the LabVIEW
	 * Dashboard, remove all of the chooser code and uncomment the getString code to get the auto name from the text box
	 * below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the chooser code above (like the commented example)
	 * or additional comparisons to the switch structure below with additional strings & commands.
	 */
    public void autonomousInit() {
        //autonCommand = (Command) chooser.getSelected();
    	//autonCommand.start();
        
		/* String autoSelected = SmartDashboard.getString("Auto Selector", "Default");
		switch(autoSelected) {
		case "My Auto":
			autonomousCommand = new MyAutoCommand();
			break;
		case "Default Auto":
		default:
			autonomousCommand = new ExampleCommand();
			break;
		} */
    	
    	
    	
    	 autonCommand = new AutonomousCommand();
    	
    	// schedule the autonomous command (example)
        if (autonCommand != null){
        	
        	chassis.resetAllDis(0.0);
        	autonCommand.start();
        }
        
        //System.out.println("Work you!");
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
        Scheduler.getInstance().run();
    }

    public void teleopInit() {
		// This makes sure that the autonomous stops running when
        // teleop starts running. If you want the autonomous to 
        // continue until interrupted by another command, remove
        // this line or comment it out.
        if (autonCommand != null) autonCommand.cancel();
        
        
        //check = new CompressorCheck();
   
        //check.start();
        
        // hack to temporarily set speed
        shooter.setSpeed( 1.0 );
        
        //System.out.println("Please, please");
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
        Scheduler.getInstance().run();
        /*
        // DOES THIS WORK?
        if( compy.getClosedLoopControl() == true ) {
        	spike.set(Relay.Value.kForward);
        }
        else if( compy.getClosedLoopControl() == false ) {
        	spike.set(Relay.Value.kOff);
        }*/
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
        LiveWindow.run();
    }
}
